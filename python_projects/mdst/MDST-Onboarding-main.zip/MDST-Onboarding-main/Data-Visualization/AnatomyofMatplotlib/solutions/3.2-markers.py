t = np.arange(0.0, 5.0, 0.2)
plt.plot(t, t, "*y", t, t**2, "8m", t, t**3, "sg")
plt.show()
